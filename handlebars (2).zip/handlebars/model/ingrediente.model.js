const { DataTypes } = require('sequelize');
const sequelize = require('../config/database');

const Ingrediente = sequelize.define('Ingrediente', {
    nome: {
        type: DataTypes.STRING,
        allowNull: false
    },
    tipo: {
        type: DataTypes.STRING,
        allowNull: false  
    },
    validade: {
        type: DataTypes.STRING,
        allowNull: false   //n pode null
    }
});


module.exports = Ingrediente;