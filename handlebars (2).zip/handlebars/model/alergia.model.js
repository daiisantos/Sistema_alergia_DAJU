const { DataTypes } = require('sequelize');
const sequelize = require('../config/database');

const Alergia = sequelize.define('Alergia', {
    nome: {
        type: DataTypes.STRING,
        allowNull: false
    },
    gravidade: {
        type: DataTypes.STRING,
        allowNull: false  
    },
    sintomas: {
        type: DataTypes.STRING,
        allowNull: false   //n pode null
    }
});


module.exports = Alergia;