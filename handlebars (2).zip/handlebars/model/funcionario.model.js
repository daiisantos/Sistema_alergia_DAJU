const { DataTypes } = require('sequelize');
const sequelize = require('../config/database');

const Funcionario = sequelize.define('Funcionario', {
    nome: {
        type: DataTypes.STRING,
        allowNull: false
    },
    idade: {
        type: DataTypes.INTEGER,
        allowNull: false  
    },
    CPF: {
        type: DataTypes.STRING,
        allowNull: false   
    }
});


module.exports = Funcionario;