const { DataTypes } = require('sequelize');
const sequelize = require('../config/database');

const Comida = sequelize.define('Comida', {
    nome: {
        type: DataTypes.STRING,
        allowNull: false
    },
    tipo: {
        type: DataTypes.STRING,
        allowNull: false  
    },
    preco: {
        type: DataTypes.FLOAT,
        allowNull: false   //n pode null
    }
});


module.exports = Comida;