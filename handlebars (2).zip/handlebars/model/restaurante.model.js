const { DataTypes } = require('sequelize');
const sequelize = require('../config/database');

const Restaurante = sequelize.define('Restaurante', {
    nome: {
        type: DataTypes.STRING,
        allowNull: false
    },
    endereco: {
        type: DataTypes.STRING,
        allowNull: false  
    },
    CNPJ: {
        type: DataTypes.STRING,
        allowNull: false   //n pode null
    }
});


module.exports = Restaurante;