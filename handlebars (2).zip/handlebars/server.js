const express = require('express');
const exphbs = require('express-handlebars');

const app = express();
const port = 3000;

//IMPORTAÇÃO DE USUARIO
const Usuario = require('./model/usuario.model');//novo
const db = require('./config/database');//novo
//IMPORTAÇÃO DE RESTAURANTE
const Restaurante = require('./model/restaurante.model');
//IMPORTAÇÃO DE FUNCIONARIO
const Funcionario = require('./model/funcionario.model');
//IMPORTAÇÃO DE ALERGIA
const Alergia = require('./model/alergia.model');
//IMPORTAÇÃO DE COMIDA
const Comida = require('./model/comida.model');
//IMPORTAÇÃO DE INGREDIENTES
const Ingrediente = require('./model/ingrediente.model');

app.use(express.json());
app.use(express.urlencoded({ extended: true }));

app.engine('handlebars', exphbs.engine({ defaultLayout: false }));
app.set("view engine", "handlebars");


//--------------------HOME------------------------------
app.get('/', (req, res) => {
    res.render/*renderizar a view home*/('home'); //toda iew tem por padrão'.handlebars' 
});

//--------------------------------LET Usuarios--------------------------------

//  let usuarios = [
//      { id: 1, nome: 'Juliana',idade: 14, CPF: '12345645342'},
//     { id: 2, nome: 'Daiane', idade: 19, CPF: '12345645344'},
//     { id: 3, nome: 'Eric', idade: 33, CPF: '12345645343'},
// ];

//----------------------------------CRUD USUÁRIOS------------------------------------



//LISTAR usuarios
app.get('/usuarios', async (req, res) => {
    try {
        let usuarios = await Usuario.findAll({ raw: true }); //embora seja asíncrona, com o await ele espera

        res.render('listarUsuarios', { usuarios });
    } catch (error) {
        console.error('Erro ao buscar usuarios:', error);
        res.status(500).send('Erro ao buscar usuarios');
    }
});

//CADASTRAR Usuario
//parte1
app.get('/usuarios/novo', (req, res) => {
    res.render('cadastrarUsuario');
});

//parte2 (salvar ao clicar)
app.post('/usuarios', async (req, res) => {

    try {
        await Usuario.create({
            nome: req.body.nome,
            idade: req.body.idade,
            CPF: req.body.CPF
        });


        res.redirect('/usuarios');

    } catch (error) {
        console.error('Erro ao buscar usuarios:', error);
        res.status(500).send('Erro ao buscar usuarios');
    }

});

//Detalhar Usuario

app.get('/usuarios/:id', async (req, res) => {
    try {
        const usuarioDetalhar = await Usuario.findByPk(req.params.id, { raw: true });

        res.render('detalharUsuario', { usuario: usuarioDetalhar });
    } catch (error) {
        console.error('Erro ao buscar usuarios:', error);
        res.status(500).send('Erro ao buscar usuarios:');
    }

});


//EDITAR Usuario

//parte1
app.get('/usuarios/:id/editar', async (req, res) => {
    try {
        const usuarioEditar = await Usuario.findByPk(req.params.id, { raw: true });
        if (!usuarioEditar) return res.status(404).send('Usuário não encontrado');//adicionoi isso
        res.render('editarUsuario', { usuario: usuarioEditar });
    } catch (error) {
        console.error('Erro ao buscar usuário:', error);
        res.status(500).send('Erro ao buscar usuário');
    }
});

//parte2
app.post('/usuarios/:id/editar', async (req, res) => {
    try {
        const usuarioAtualizar = await Usuario.findByPk(req.params.id);
        if (!usuarioAtualizar) return res.status(404).send('Usuário não encontrado');//add isso


        usuarioAtualizar.nome = req.body.nome;
        usuarioAtualizar.idade = req.body.idade;
        usuarioAtualizar.CPF = req.body.CPF;

        await usuarioAtualizar.save();

        res.render('listarUsuarios', { usuario: usuarioListar });
    } catch (error) {
        console.error('Erro ao editar usuário:', error);
        res.status(500).send('Erro ao editar usuário');
    }
});

//EXCLUIR Usuario

app.post('/usuarios/excluir/:id', async (req, res) => {
    try {
        const usuarioExcluir = await Usuario.findByPk(req.params.id);

        if (!usuarioExcluir) {
            return res.status(404).send('Usuário não encontrado');
        }

        await usuarioExcluir.destroy();

        res.redirect('/usuarios'); //mudei de render pra redirect
    } catch (error) {
        console.error('Erro ao excluir usuário:', error);
        res.status(500).send('Erro ao excluir usuário');
    }
});

//---------------------------------LET ALERGIAS-------------------------------------
// let alergias = [
//     { id: 1, nome: 'Frutos  do mar', descricao:'Peixes, Camarão, Caranguejo'},
//     { id: 2, nome: 'Lactose', descricao:'Leite, Yogurt, queijo'},
//     { id: 3, nome: 'glúten',descricao:'Trigo, Bolo, Pão'},

// ];

//---------------------------------CRUD ALERGIAS-------------------------------------



// LISTAR Alergias
app.get('/alergias', async (req, res) => {
    try {
        let alergias = await Alergia.findAll({ raw: true });

        res.render('listarAlergias', { alergias });
    } catch (error) {
        console.error('Erro ao buscar alergias:', error);
        res.status(500).send('Erro ao buscar alergias');
    }
});


// CADASTRAR Alergia 
app.get('/alergias/nova', (req, res) => {
    res.render('cadastrarAlergia');
});


// CADASTRAR Alergia 
app.post('/alergias', async (req, res) => {
    try {
        await Alergia.create({
            nome: req.body.nome,
            gravidade: req.body.gravidade,
            sintomas: req.body.sintomas
        });

        res.redirect('/alergias');
    } catch (error) {
        console.error('Erro ao cadastrar alergia:', error);
        res.status(500).send('Erro ao cadastrar alergia');
    }
});


// DETALHAR Alergia
app.get('/alergias/:id', async (req, res) => {
    try {
        const alergiaDetalhar = await Alergia.findByPk(req.params.id, { raw: true });

        if (!alergiaDetalhar) {
            return res.status(404).send('Alergia não encontrada');
        }

        res.render('detalharAlergia', { alergia: alergiaDetalhar });
    } catch (error) {
        console.error('Erro ao buscar alergia:', error);
        res.status(500).send('Erro ao buscar alergias');
    }
});


// EDITAR Alergia
app.get('/alergias/:id/editar', async (req, res) => {
    try {
        const alergiaEditar = await Alergia.findByPk(req.params.id, { raw: true });

        if (!alergiaEditar) {
            return res.status(404).send('Alergia não encontrada');
        }

        res.render('editarAlergia', { alergia: alergiaEditar });
    } catch (error) {
        console.error('Erro ao buscar alergia:', error);
        res.status(500).send('Erro ao buscar alergias');
    }
});


// EDITAR Alergia – salvar
app.post('/alergias/:id/editar', async (req, res) => {
    try {
        const alergiaAtualizar = await Alergia.findByPk(req.params.id);

        if (!alergiaAtualizar) {
            return res.status(404).send('Alergia não encontrada');
        }

        alergiaAtualizar.nome = req.body.nome;
        alergiaAtualizar.gravidade = req.body.gravidade;
        alergiaAtualizar.sintomas = req.body.sintomas;

        await alergiaAtualizar.save();

        const alergiasListar = await Alergia.findAll({ raw: true });

        res.render('listarAlergias', { alergias: alergiasListar });
    } catch (error) {
        console.error('Erro ao editar alergia:', error);
        res.status(500).send('Erro ao editar alergia');
    }
});


// EXCLUIR Alergia
app.post('/alergias/excluir/:id', async (req, res) => {
    try {
        const alergiaExcluir = await Alergia.findByPk(req.params.id);

        if (!alergiaExcluir) {
            return res.status(404).send('Alergia não encontrada');
        }

        await alergiaExcluir.destroy();

        res.redirect('/alergias');
    } catch (error) {
        console.error('Erro ao excluir alergia:', error);
        res.status(500).send('Erro ao excluir alergia');
    }
});



//--------------------------------LET restaurantes--------------------------------

// let restaurantes = [
//     { id: 1, nome: 'Bistrô Do Chef', endereco: 303, CNPJ: '45.678.912/0001-34' },
//     { id: 2, nome: 'Tempero da Serra', endereco: 404, CNPJ: '56.789.123/0001-56' },
//     { id: 3, nome: 'Mar & Brasa Seafood', endereco: 505, CNPJ: '67.891.234/0001-78' }
// ];


//-------------------------------------CRUD restaurantes--------------------------------

//LISTAR
app.get('/restaurantes', async (req, res) => {
    try {
        let restaurantes = await Restaurante.findAll({ raw: true }); //embora seja asíncrona, com o await ele espera

        res.render('listarRestaurantes', { restaurantes });
    } catch (error) {
        console.error('Erro ao buscar restaurantes:', error);
        res.status(500).send('Erro ao buscar restaurantes');
    }
});

//CADASTRAR restaurantes
app.get('/restaurantes/novo', (req, res) => {
    res.render('cadastrarRestaurante');
});
//part2
app.post('/restaurantes', async (req, res) => {
    try {
        await Restaurante.create({
            nome: req.body.nome,
            endereco: req.body.endereco,
            CNPJ: req.body.CNPJ
        });


        res.redirect('/restaurantes');

    } catch (error) {
        console.error('Erro ao buscar restaurantes', error);
        res.status(500).send('Erro ao buscar restaurantes');
    }

});
//Detalhar restaurantes

app.get('/restaurantes/:id', async (req, res) => {
    try {
        const restauranteDetalhar = await Restaurante.findByPk(req.params.id, { raw: true });

        res.render('detalharRestaurante', { restaurante: restauranteDetalhar });
    } catch (error) {
        console.error('Erro ao buscar restaurantes', error);
        res.status(500).send('Erro ao buscar restaurantes');
    }

});


//EDITAR restaurantes

//1
app.get('/restaurantes/:id/editar', async (req, res) => {
    try {
        const restauranteEditar = await Restaurante.findByPk(req.params.id, { raw: true });
        if (!restauranteEditar) return res.status(404).send('Restaurante não encontrado');//adicionei isso
        res.render('editarRestaurante', { restaurante: restauranteEditar });
    } catch (error) {
        console.error('Erro ao buscar restaurantes', error);
        res.status(500).send('Erro ao buscar restaurantes');
    }
});

//2
app.post('/restaurantes/:id/editar', async (req, res) => {
    try {
        const restauranteAtualizar = await Restaurante.findByPk(req.params.id);
        if (!restauranteAtualizar) return res.status(404).send('Restaurante não encontrado');


        restauranteAtualizar.nome = req.body.nome;
        restauranteAtualizar.endereco = req.body.endereco;
        restauranteAtualizar.CNPJ = req.body.CNPJ;

        await restauranteAtualizar.save();


        const restauranteListar = await Restaurante.findAll({ raw: true });

        res.render('listarRestaurantes', { restaurantes: restauranteListar });
    } catch (error) {
        console.error('Erro ao buscar restaurantes', error);
        res.status(500).send('Erro ao buscar restaurantes');
    }
});

//EXCLUIR restaurantes

app.post('/restaurantes/excluir/:id', async (req, res) => {
    try {
        const restauranteExcluir = await Restaurante.findByPk(req.params.id);

        if (!restauranteExcluir) {
            return res.status(404).send('Restaurante não encontrado');
        }

        await restauranteExcluir.destroy();

        res.redirect('/restaurantes'); //mudei de render pra redirect
    } catch (error) {
        console.error('Erro ao buscar restaurantes:', error);
        res.status(500).send('Erro ao buscar restaurantes');
    }
});

//----------------------------------NOVO CRUD Funcionários------------------------------------


//LISTAR funcionarios
app.get('/funcionarios', async (req, res) => {
    try {
        let funcionarios = await Funcionario.findAll({ raw: true }); //embora seja asíncrona, com o await ele espera

        res.render('listarFuncionario', { funcionarios });
    } catch (error) {
        console.error('Erro ao buscar funcionarios', error);
        res.status(500).send('Erro ao buscar funcionarios');
    }
});

//CADASTRAR Usuario
//parte1
app.get('/funcionarios/novo', (req, res) => {
    res.render('cadastrarFuncionario');
});

//parte2 (salvar ao clicar)
app.post('/funcionarios', async (req, res) => {

    try {
        await Funcionario.create({
            nome: req.body.nome,
            idade: req.body.idade,
            CPF: req.body.CPF
        });


        res.redirect('/funcionarios');

    } catch (error) {
        console.error('Erro ao buscar funcionarios:', error);
        res.status(500).send('Erro ao buscar funcionarios');
    }

});

//Detalhar funcionario

app.get('/funcionarios/:id', async (req, res) => {
    try {
        const funcionarioDetalhar = await Funcionario.findByPk(req.params.id, { raw: true });

        res.render('detalharFuncionario', { funcionario: funcionarioDetalhar });
    } catch (error) {
        console.error('Erro ao buscar funcionarios:', error);
        res.status(500).send('Erro ao buscar funcionarios:');
    }

});


//EDITAR Usuario

//parte1
app.get('/funcionarios/:id/editar', async (req, res) => {
    try {
        const funcionarioEditar = await Funcionario.findByPk(req.params.id, { raw: true });
        if (!funcionarioEditar) return res.status(404).send('funcionario não encontrado');//adicionoi isso
        res.render('editarFuncionario', { funcionario: funcionarioEditar });
    } catch (error) {
        console.error('Erro ao buscar funcionarios:', error);
        res.status(500).send('Erro ao buscar funcionarios');
    }
});

//parte2
app.post('/funcionarios/:id/editar', async (req, res) => {
    try {
        const funcionarioAtualizar = await Funcionario.findByPk(req.params.id);
        if (!funcionarioAtualizar) return res.status(404).send('Funcionario não encontrado');

        funcionarioAtualizar.nome = req.body.nome;
        funcionarioAtualizar.idade = req.body.idade;
        funcionarioAtualizar.CPF = req.body.CPF;

        await funcionarioAtualizar.save();


        const funcionarioListar = await Funcionario.findAll({ raw: true });

        res.render('listarFuncionario', { funcionarios: funcionarioListar });
    } catch (error) {
        console.error('Erro ao editar funcionarios', error);
        res.status(500).send('Erro ao editar funcionarios');
    }
});

//EXCLUIR Usuario

app.post('/funcionarios/excluir/:id', async (req, res) => {
    try {
        const funcionarioExcluir = await Funcionario.findByPk(req.params.id);

        if (!funcionarioExcluir) {
            return res.status(404).send('funcionario não encontrado');
        }

        await funcionarioExcluir.destroy();

        res.redirect('/funcionarios');
    } catch (error) {
        console.error('Erro ao excluir funcionarios:', error);
        res.status(500).send('Erro ao excluir funcionarios');
    }
});




// LISTAR Comidas
app.get('/comidas', async (req, res) => {
    try {
        const comidas = await Comida.findAll({ raw: true });

        res.render('listarComidas', { comidas });
    } catch (error) {
        console.error('Erro ao buscar comidas:', error);
        res.status(500).send('Erro ao buscar comidas');
    }
});

// CADASTRAR Comida
app.get('/comidas/nova', (req, res) => {
    res.render('cadastrarComida');
});

app.post('/comidas', async (req, res) => {
    try {
        await Comida.create({
            nome: req.body.nome,
            tipo: req.body.tipo,
            preco: req.body.preco
        });

        res.redirect('/comidas');
    } catch (error) {
        console.error('Erro ao cadastrar comida:', error);
        res.status(500).send('Erro ao cadastrar comida');
    }
});

// DETALHAR Comida
app.get('/comidas/:id', async (req, res) => {
    try {
        const comida = await Comida.findByPk(req.params.id, { raw: true });

        res.render('detalharComida', { comida });
    } catch (error) {
        console.error('Erro ao buscar comida:', error);
        res.status(500).send('Erro ao buscar comida');
    }
});

// EDITAR Comida
app.get('/comidas/:id/editar', async (req, res) => {
    try {
        const comida = await Comida.findByPk(req.params.id, { raw: true });

        if (!comida) return res.status(404).send('Comida não encontrada');

        res.render('editarComida', { comida });
    } catch (error) {
        console.error('Erro ao buscar comida:', error);
        res.status(500).send('Erro ao buscar comida');
    }
});

app.post('/comidas/:id/editar', async (req, res) => {
    try {
        const comidaAtualizar = await Comida.findByPk(req.params.id);

        if (!comidaAtualizar) return res.status(404).send('Comida não encontrada');

        comidaAtualizar.nome = req.body.nome;
        comidaAtualizar.tipo = req.body.tipo;
        comidaAtualizar.preco = req.body.preco;

        await comidaAtualizar.save();

        const comidas = await Comida.findAll({ raw: true });

        res.render('listarComidas', { comidas });
    } catch (error) {
        console.error('Erro ao editar comida:', error);
        res.status(500).send('Erro ao editar comida');
    }
});

// EXCLUIR Comida
app.post('/comidas/excluir/:id', async (req, res) => {
    try {
        const comidaExcluir = await Comida.findByPk(req.params.id);

        if (!comidaExcluir) {
            return res.status(404).send('Comida não encontrada');
        }

        await comidaExcluir.destroy();

        res.redirect('/comidas');
    } catch (error) {
        console.error('Erro ao excluir comida:', error);
        res.status(500).send('Erro ao excluir comida');
    }
});


// LISTAR Ingredientes
app.get('/ingredientes', async (req, res) => {
    try {
        let ingredientes = await Ingrediente.findAll({ raw: true });

        res.render('listarIngredientes', { ingredientes });
    } catch (error) {
        console.error('Erro ao buscar os ingredientes', error);
        res.status(500).send('Erro ao buscar os ingredientes');
    }
});

// CADASTRAR Ingrediente
app.get('/ingredientes/novo', (req, res) => {
    res.render('cadastrarIngrediente');
});

app.post('/ingredientes', async (req, res) => {
    try {
        await Ingrediente.create({
            nome: req.body.nome,
            tipo: req.body.tipo,
            validade: req.body.validade
        });

        res.redirect('/ingredientes');
    } catch (error) {
        console.error('Erro ao cadastrar ingrediente:', error);
        res.status(500).send('Erro ao cadastrar ingrediente');
    }
});

// DETALHAR Ingrediente
app.get('/ingredientes/:id', async (req, res) => {
    try {
        const ingredienteDetalhar = await Ingrediente.findByPk(req.params.id, { raw: true });

        res.render('detalharIngrediente', { ingrediente: ingredienteDetalhar });
    } catch (error) {
        console.error('Erro ao buscar ingrediente:', error);
        res.status(500).send('Erro ao buscar ingrediente');
    }
});

// EDITAR Ingrediente
app.get('/ingredientes/:id/editar', async (req, res) => {
    try {
        const ingredienteEditar = await Ingrediente.findByPk(req.params.id, { raw: true });

        if (!ingredienteEditar) return res.status(404).send('Ingrediente não encontrado');

        res.render('editarIngrediente', { ingrediente: ingredienteEditar });
    } catch (error) {
        console.error('Erro ao buscar ingrediente:', error);
        res.status(500).send('Erro ao buscar ingrediente');
    }
});

app.post('/ingredientes/:id/editar', async (req, res) => {
    try {
        const ingredienteAtualizar = await Ingrediente.findByPk(req.params.id);

        if (!ingredienteAtualizar) return res.status(404).send('Ingrediente não encontrado');

        ingredienteAtualizar.nome = req.body.nome;
        ingredienteAtualizar.tipo = req.body.tipo;
        ingredienteAtualizar.validade = req.body.validade;

        await ingredienteAtualizar.save();

        const ingredientesListar = await Ingrediente.findAll({ raw: true });

        res.render('listarIngredientes', { ingredientes: ingredientesListar });
    } catch (error) {
        console.error('Erro ao editar ingrediente', error);
        res.status(500).send('Erro ao editar ingrediente');
    }
});

// EXCLUIR Ingrediente
app.post('/ingredientes/excluir/:id', async (req, res) => {
    try {
        const ingredienteExcluir = await Ingrediente.findByPk(req.params.id);

        if (!ingredienteExcluir) {
            return res.status(404).send('Ingrediente não encontrado');
        }

        await ingredienteExcluir.destroy();

        res.redirect('/ingredientes');
    } catch (error) {
        console.error('Erro ao excluir ingrediente:', error);
        res.status(500).send('Erro ao excluir ingrediente');
    }
});







//-----------------------BANCO DE DADOS---------------------------

db.sync({ force: true })
    .then(() => {
        console.log('Banco de daods sinconizado!!!');
    })
    .catch((e) => {
        console.error('ERRO AO SICRONIZAR COM O BANCO DE DADOS!!!!', e);
    });//novo


//------------------------LISTEN-------------------------------
app.listen(port, () => {
    console.log(`servidor em execução: http://localhost:${port}`); //tem que ser cráse
});



